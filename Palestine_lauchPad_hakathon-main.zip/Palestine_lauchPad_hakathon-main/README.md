# Palestine_lauchPad_hakathon
i was one of the group who made this :)
